#pragma once
bool IsEmpty(int *size);
void Clear(int *size);
void Push(char *S, int *size, char *x);
void Pop(int *size);
char Top(char *S, int *size);
int trans(char n);
